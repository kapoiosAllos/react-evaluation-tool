import React, { PureComponent } from 'react'
import { connect } from 'react-redux'
import { fetch as fetchStudent } from '../actions/student'
import Title from '../components/Title'
import StudentEditor from './StudentEditor'
//import BatchEditor from './BatchEditor'


class StudentContainer extends PureComponent {
  componentWillMount() {
    this.props.dispatch(fetchStudent(this.props.match.params.id))
  }
  renderEvaluations(evaluations) {
    const evdata = evaluations.map( evaluation => { 
      let tdstyle= {
        background: evaluation.color,
      };
      return (
        <tr>
          <td>{evaluation.createAt}</td>
          <td style={tdstyle}>{evaluation.remark}</td>
          <td>{evaluation.userid}</td>
        </tr>);
    });
    return (
      <table border="1">
      <tr>
        <th>Date</th>
        <th>Remark</th> 
        <th>TeacherID</th>
      </tr>
      <tbody>
        {evdata}
      </tbody>
    </table>
    )
  }
  render() {
    //const { student }  = this.props
    //if (!student) { return <div> Loading </div> }
    if (this.props.student)
    {var student = this.props.student;
    return(
      
      <div className="StudentContainer">
        <header>
          <Title content={`Student: ${student.name}`} />
        </header>

        <main>
          <div className="studentPhoto">
            <img src={student.photo} alt={student.name} />
          </div>
          <div className="studentDetails">
            <div className="title">Name:{student.name}</div>
            <div>Evaluations</div>
            <div className="evaluations">{this.renderEvaluations(student.evaluations)} </div>

          </div>
          <StudentEditor student={student} />
        </main>
      </div>
    )} else { return null }
  }
}

const mapStateToProps = ({ student }) => ({ ...student })

export default connect(mapStateToProps)(StudentContainer)