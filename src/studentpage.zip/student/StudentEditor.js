import React, { PureComponent } from 'react'
import { connect } from 'react-redux'
import 'medium-editor/dist/css/medium-editor.css'
import 'medium-editor/dist/css/themes/default.css'
import updateStudent from '../actions/student/update'
import Title from '../components/Title'
import MuiThemeProvider from 'material-ui/styles/MuiThemeProvider';



class BatchEditor extends PureComponent {
  constructor(props) {
    super()

    this.state = props.student

  }

  updateName(event) {
    if (event.keyCode === 13) {
      event.preventDefault()
      this.refs.name.medium.elements[0].focus()
    }
    this.setState({
      name: this.refs.name.value
    })
  }
  updatePhoto(event) {
    if (event.keyCode === 13) {
      event.preventDefault()
      this.refs.photo.medium.elements[0].focus()
    }
    this.setState({
      photo: this.refs.photo.value
    })
  }

  saveStudent() {
    console.table(this.state)

    const student= {
      ...this.state
    }

    console.table(student)

    this.props.save(student)
  }

  render() {
    console.log(this.state)
    return (
        <MuiThemeProvider>
      <div className="editor">
      <header>
        <Title content="Modify Name or Photo" />
      </header>
        <label>Student's Name:</label>
        <input
          type="text"
          ref="name"
          className="name"
          placeholder="name"
          onChange={this.updateName.bind(this)}
          onKeyUp={this.updateName.bind(this)}
          value={this.state.name} />
          <label>Student's Photo:</label>
          <input
          type="text"
          ref="photo"
          className="photo"
          placeholder="photo"
          onChange={this.updatePhoto.bind(this)}
          onKeyUp={this.updatePhoto.bind(this)} 
          value={this.state.photo}/>


        <div className="actions">
          <button className="primary" onClick={this.saveStudent.bind(this)}>Update</button>
        </div>
      </div>
        </MuiThemeProvider>
    )
  }
}

const mapDispatchToProps = { save: updateStudent }

export default connect(null, mapDispatchToProps)(BatchEditor)
